public interface IBonus {
    public Double getValorBonus();
}
