insert into usuario
(login, senha, nome)
values
('camargovic', '12345', 'Victoria'),
('julinhalinda', '98765', 'Julia'),
('selmaandrade', '34567', 'Selma');