package com.sptech.provac2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Provac2Application {

	public static void main(String[] args) {
		SpringApplication.run(Provac2Application.class, args);
	}

}
