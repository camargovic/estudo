package sptech.projetojpa06;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoJpa07ApplicationTests {

	@Test
	void contextLoads() {
	}

}
