package sptech.projetojpa07;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoJpa07Application {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoJpa07Application.class, args);
	}

}
